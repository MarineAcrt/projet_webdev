/**
 * V�rifie que les deux champs de saisie sont remplis.
 */
function login_validerForm() {
    var valide = true;
    var l = document.getElementById('j_username');
    var p = document.getElementById('j_password');
    if (l.value == "") {
        l.style.background = "#FFB5B5";
        l.focus();
        alert("Veuillez saisir votre identifiant de connexion.");
        valide = false;
    }
    if (p.value == "") {
        p.style.background = "#FFB5B5";
        p.focus();
        alert("Veuillez saisir votre mot de passe.");
        valide = false;
    }
    return valide;
}

function getXMLHttpRequest() {
    var xhr = null;
    if (window.XMLHttpRequest || window.ActiveXObject) {
        if (window.ActiveXObject) {
            try {
                xhr = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                xhr = new ActiveXObject("Microsoft.XMLHTTP");
            }
        } else {
            xhr = new XMLHttpRequest();
        }
    } else {
        alert("Votre navigateur ne supporte pas l'objet XMLHTTPRequest...");
        return null;
    }
    return xhr;
}


function initSaiku(url, userName, password) {
    var isConnected = (getCookie("isConnCookie")== 'true');
    if (!isConnected) {
        loginSessionSaiku(url, userName, password);
    } else {
        refreshCacheSaiku(url, userName);
    }
}

/**
 * Authentification de l'utilisateur connect� � Web Aurion
 * 
 * @param {type} url
 * @param {type} userName
 * @param {type} password
 * @returns {undefined}
 */
function loginSessionSaiku(url, userName, password) {
    var xhr = getXMLHttpRequest();
    xhr.open("POST", url + "/rest/saiku/session/", false);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send("username=" + userName + "&password=" + password);
    var isConnected = checkConnectionSaiku(url);
    setCookie("isConnCookie", isConnected, 30);
    
    if (isConnected) {
        refreshCacheSaiku(url, userName);
    }
}

/**
 * Deconnexion de l(utilisateur
 * 
 * @param {type} url
 * @returns {undefined}
 */
function logoutSessionSaiku(url) {
    var xhr = getXMLHttpRequest();
    xhr.open("DELETE", url + "/rest/saiku/session/", false);
    xhr.send();
    setCookie("isConnCookie", false, 30);
}

/**
 * V�rifier si l'utilisateur est d"ja connect�
 * 
 * @param {type} url
 * @returns {Boolean}
 */
function checkConnectionSaiku(url) {
    var xhr = getXMLHttpRequest();
    xhr.open("GET", url + "/rest/saiku/session/", false);
    xhr.send();
    return (xhr.responseText).indexOf("sessionid") !== -1;
}

/**
 * Rafrichir le cache sa Saiku pour charger les nouveaux fichiers
 * 
 * @param {type} url
 * @param {type} user
 * @returns {undefined}
 */
function refreshCacheSaiku(url, user) {
    var xhr = getXMLHttpRequest();
    xhr.open("GET", url + "/rest/saiku/" + user + "/discover/refresh", false);
    xhr.send();
}

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/saiku";
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}